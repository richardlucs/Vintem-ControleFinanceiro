﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Vintém___Controle_Financeiro.Classes
{
    public class Login
    {
        private string _Usuário;

        public string Usuário
        {
            get { return _Usuário; }
            set { _Usuário = value; }
        }

        private string _Senha;

        public string Senha
        {
            get { return _Senha; }
            set { _Senha = value; }
        }

        private string _PIN;

        public string PIN
        {
            get { return _PIN; }
            set { _PIN = value; }
        }

        public Login()
        {
            _PIN = Guid.NewGuid().ToString().Substring(9, 4).ToUpper();          
        }
    }
}
