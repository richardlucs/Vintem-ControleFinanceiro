﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Vintém___Controle_Financeiro.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Classes
{
    class gerCTC : Lançamento
    {
        ArrayList CTControle = new ArrayList();
        Lançamento MeusLançamentos;
        
        public void FazLançamento(double valor, string tipo, string data, string nomeCF)
        {
            LerDados();
            MeusLançamentos = new Lançamento();
            MeusLançamentos.NomeCF = nomeCF;
            MeusLançamentos.ValorLanc = valor;
            MeusLançamentos.TipoLanc = tipo;
            MeusLançamentos.DataLanc = data;
           
            CTControle.Add(MeusLançamentos);
            GravaDados(CTControle);
        }

        public void GravaDados(ArrayList MeuArray)
        {
            TextWriter MeuWriter = new StreamWriter(@"CTC.xml");

            Lançamento[] ListaCTC = (Lançamento[])MeuArray.ToArray(typeof(Lançamento));

            XmlSerializer Serialização = new XmlSerializer(ListaCTC.GetType());

            Serialização.Serialize(MeuWriter, ListaCTC);

            MeuWriter.Close();
        }

        public ArrayList LerDados()
        {
            FileStream Arquivo = new FileStream(@"CTC.xml", FileMode.Open);

            Lançamento[] ListaCTC = (Lançamento[])CTControle.ToArray(typeof(Lançamento));

            XmlSerializer Desserialização = new XmlSerializer(ListaCTC.GetType());

            ListaCTC = (Lançamento[])Desserialização.Deserialize(Arquivo);

            CTControle.Clear();

            CTControle.AddRange(ListaCTC);
            Arquivo.Close();

            return CTControle;
        }
    }
}
