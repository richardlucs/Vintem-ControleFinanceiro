﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Vintém___Controle_Financeiro.Classes
{
    class OperaçõesLogin
    {
        public void FazCadastro(string usuário, string senha)
        {
            bool jáTem = false;

            XElement Raiz = XElement.Load(@"usuários.xml");

            var Consulta = from L in Raiz.Elements("Login")
                           select new
                           {
                               UsuárioArq = (string)(L.Element("Usuário")),
                               SenhaArq = (string)(L.Element("Senha")),
                               PINarq = (string)(L.Element("PIN")),
                           };

            Login MeuLogin = new Login();

            MeuLogin.Usuário = usuário;
            MeuLogin.Senha = senha;

            foreach (var x in Consulta)
            {
                if (usuário == x.UsuárioArq)
                {
                    jáTem = true;                    
                }              
            }

            if (jáTem == true)
            {
                MessageBox.Show("O usuário já existe!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }          
            else
            {
                XElement NovoLogin = new XElement("Login",
                                        new XElement("Usuário", MeuLogin.Usuário),
                                        new XElement("Senha", MeuLogin.Senha),
                                        new XElement("PIN", MeuLogin.PIN));

                Raiz.Add(NovoLogin);
                Raiz.Save(@"usuários.xml");
                MessageBox.Show("Usuário criado com sucesso!\n\n--Seus dados--\nLogin: "+MeuLogin.Usuário+"\nSenha: "+MeuLogin.Senha+"\nPIN para recuperar senha: "+MeuLogin.PIN, "Feito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public int VerificaDados(string usuário, string PIN)
        {
            XElement Raiz = XElement.Load(@"usuários.xml");

            var Consulta = from L in Raiz.Elements("Login")
                           select new
                           {
                               UsuárioArq = (string)(L.Element("Usuário")),
                               PINarq = (string)(L.Element("PIN")),
                           };

            Login MeuLogin = new Login();

            MeuLogin.Usuário = usuário;
            MeuLogin.PIN = PIN;

            foreach (var x in Consulta)
            {
                if (usuário == x.UsuárioArq && PIN == x.PINarq)
                {
                    return 1;
                }
                else if ((usuário == x.UsuárioArq && PIN != x.PINarq) | (usuário != x.UsuárioArq && PIN == x.PINarq))
                {
                    return 2;
                }
                else if (usuário != x.UsuárioArq && PIN != x.PINarq)
                {
                    return 3;
                }
            }

            return 3;
        }

        public void TrocaSenha(string senhaN, string senhaC, string usuário)
        {
            XElement Raiz = XElement.Load(@"usuários.xml");

            Login MeuLogin = new Login();

            var SenhaAlterar = from S in Raiz.Elements("Login")
                               where ((string)S.Element("Usuário")).Equals(usuário)
                               select S;

            foreach (XElement xe in SenhaAlterar)
            {
                xe.SetElementValue("Senha", senhaN);
            }

            Raiz.Save(@"usuários.xml");
            MessageBox.Show("Senha trocada com sucesso!", "Feito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public int FazLogin(string usuário, string senha)
        {
            int Elemento = 0;
            bool achou = false;

            XElement Raiz = XElement.Load(@"usuários.xml");

            var Consulta = from L in Raiz.Elements("Login")
                           select new
                           {
                               UsuárioArq = (string)(L.Element("Usuário")),
                               SenhaArq = (string)(L.Element("Senha")),
                           };

            Login MeuLogin = new Login();

            MeuLogin.Usuário = usuário;
            MeuLogin.Senha = senha;

            foreach (var x in Consulta)
            {
                if(achou != true)
                { 
                    if (usuário == x.UsuárioArq && senha == x.SenhaArq)
                    {
                        Elemento = 1;
                        achou = true;
                    }
                    else if ((usuário == x.UsuárioArq && senha != x.SenhaArq) || (usuário != x.UsuárioArq && senha == x.SenhaArq))
                    {
                        Elemento = 2;
                        achou = false;
                    }
                    else if (usuário != x.UsuárioArq && senha != x.SenhaArq)
                    {
                        Elemento = 3;
                        achou = false;
                    }
                }                    
            }

            return Elemento;
        }
    }
}

