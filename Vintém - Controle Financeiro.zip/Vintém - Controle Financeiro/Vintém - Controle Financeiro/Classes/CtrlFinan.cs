﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Vintém___Controle_Financeiro.Forms;

namespace Vintém___Controle_Financeiro.Classes
{
    class ControleFinanc
    {
        ArrayList Controle = new ArrayList();
        ObjetoControle MeuObjeto = new ObjetoControle();

        public ControleFinanc()
        {
            Controle = new ArrayList();
        }

        public void InserirControle(ObjetoControle x)
        {
            LerDados();
            Controle.Add(x);
            GravaDados();
        }

        public void ExcluirControle(string NomeCF)
        { 
            LerDados();

            foreach(ObjetoControle x in Controle)
            {
                if (x.NomeCF == NomeCF)
                {
                    Controle.Remove(x);
                    break;
                }
            }
            GravaDados();
        }

        public void GravaDados()
        {
            TextWriter MeuWriter = new StreamWriter(@"CtrlFinanc.xml");

            ObjetoControle[] ListaControles = (ObjetoControle[])Controle.ToArray(typeof(ObjetoControle));

            XmlSerializer Serialização = new XmlSerializer(ListaControles.GetType());

            Serialização.Serialize(MeuWriter, ListaControles);

            MeuWriter.Close();
        }

        public ArrayList LerDados()
        {
            FileStream Arquivo = new FileStream(@"CtrlFinanc.xml", FileMode.Open);

            ObjetoControle[] ListaControles = (ObjetoControle[])Controle.ToArray(typeof(ObjetoControle));

            XmlSerializer Desserialização = new XmlSerializer(ListaControles.GetType());

            ListaControles = (ObjetoControle[])Desserialização.Deserialize(Arquivo);

            Controle.Clear();

            Controle.AddRange(ListaControles);
            Arquivo.Close();

            return Controle;
        }

        public bool VerificaControle(string Nome)
        {
            LerDados();

            bool achou = false;

            foreach(ObjetoControle x in Controle)
            {
                if(achou != true)
                {
                    if(x.NomeUsu == Nome)
                    {
                        achou = true;
                    }
                    else
                    {
                        achou = false;
                    }
                }
            }
            return achou;
        }
    }

    public class Lançamento
    {
        public Lançamento()
        {
            CódLanc = Guid.NewGuid().ToString().Substring(9, 4).ToUpper();
        }

        public string CódLanc { get; set; }
        public string NomeCF { get; set; }
        public string DataLanc { get; set; }
        public double ValorLanc { get; set; }
        public string TipoLanc { get; set; }
    }
}
