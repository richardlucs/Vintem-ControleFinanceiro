﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vintém___Controle_Financeiro.Classes
{
    public class ObjetoControle
    {
        private string _CódCF;

        public string CódCF
        {
            get { return _CódCF; }
            set { _CódCF = value; }
        }

        private string _NomeUsu;

        public string NomeUsu
        {
            get { return _NomeUsu; }
            set { _NomeUsu = value; }
        }


        private string _NomeCF;

        public string NomeCF
        {
            get { return _NomeCF; }
            set { _NomeCF = value; }
        }

        public ObjetoControle()
        {
            CódCF = Guid.NewGuid().ToString().Substring(9, 4).ToUpper();
        }
    }
}
