﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaRecSenha : Form
    {
        
        public TelaRecSenha()
        {
            InitializeComponent();
        }

        private void PctbVoltar_Click(object sender, EventArgs e)
        {
            TelaLogin telaNova = new TelaLogin();

            Hide();

            telaNova.ShowDialog();
        }

        private void PctbVoltar_MouseEnter(object sender, EventArgs e)
        {
            ttpVoltar.SetToolTip(pctbVoltar, "Voltar");
        }

        private void btnAlt_Click(object sender, EventArgs e)
        {
            OperaçõesLogin MinhaOperação = new OperaçõesLogin();

            if (MinhaOperação.VerificaDados(txbUsuario.Text, txbPIN.Text) == 1)
            {
                TelaRecSenha1 telaNova = new TelaRecSenha1(txbUsuario.Text);

                Hide();

                telaNova.ShowDialog();
            }
            else if (MinhaOperação.VerificaDados(txbUsuario.Text, txbPIN.Text) == 2)
            {
                MessageBox.Show("Usuário ou PIN incorretos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                txbUsuario.Clear();
                txbPIN.Clear();
                txbUsuario.Focus();
            }
            else if (MinhaOperação.VerificaDados(txbUsuario.Text, txbPIN.Text) == 3)
            {
                MessageBox.Show("Usuário não existe!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                txbUsuario.Clear();
                txbPIN.Clear();
                txbUsuario.Focus();
            }
        }
    }
}
