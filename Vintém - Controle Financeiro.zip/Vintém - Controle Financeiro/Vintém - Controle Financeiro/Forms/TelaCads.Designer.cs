﻿using System;

namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaCads
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaCads));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCads = new System.Windows.Forms.Button();
            this.lblv = new System.Windows.Forms.Label();
            this.txbSenha = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txbUsuario = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.ttpVoltar = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.btnCads);
            this.panel1.Controls.Add(this.lblv);
            this.panel1.Controls.Add(this.txbSenha);
            this.panel1.Controls.Add(this.lbl3);
            this.panel1.Controls.Add(this.txbUsuario);
            this.panel1.Controls.Add(this.lbl2);
            this.panel1.Controls.Add(this.pctbVoltar);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 298);
            this.panel1.TabIndex = 0;
            // 
            // btnCads
            // 
            this.btnCads.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCads.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCads.Location = new System.Drawing.Point(215, 173);
            this.btnCads.Name = "btnCads";
            this.btnCads.Size = new System.Drawing.Size(82, 25);
            this.btnCads.TabIndex = 26;
            this.btnCads.Text = "Cadastrar";
            this.btnCads.UseVisualStyleBackColor = true;
            this.btnCads.Click += new System.EventHandler(this.btnCads_Click);
            // 
            // lblv
            // 
            this.lblv.AutoSize = true;
            this.lblv.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblv.ForeColor = System.Drawing.Color.Gold;
            this.lblv.Location = new System.Drawing.Point(77, 13);
            this.lblv.Name = "lblv";
            this.lblv.Size = new System.Drawing.Size(321, 32);
            this.lblv.TabIndex = 25;
            this.lblv.Text = "Cadastro de Usuário";
            this.lblv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txbSenha
            // 
            this.txbSenha.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSenha.Location = new System.Drawing.Point(195, 136);
            this.txbSenha.Name = "txbSenha";
            this.txbSenha.PasswordChar = '*';
            this.txbSenha.Size = new System.Drawing.Size(123, 22);
            this.txbSenha.TabIndex = 24;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(107, 133);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(68, 23);
            this.lbl3.TabIndex = 23;
            this.lbl3.Text = "Senha:";
            // 
            // txbUsuario
            // 
            this.txbUsuario.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbUsuario.Location = new System.Drawing.Point(195, 97);
            this.txbUsuario.Name = "txbUsuario";
            this.txbUsuario.Size = new System.Drawing.Size(123, 22);
            this.txbUsuario.TabIndex = 22;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(107, 94);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(83, 23);
            this.lbl2.TabIndex = 21;
            this.lbl2.Text = "Usuário:";
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 20;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.PctbVoltar_Click);
            this.pctbVoltar.MouseEnter += new System.EventHandler(this.pctbVoltar_MouseEnter);
            // 
            // TelaCads
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 299);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaCads";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vintém - Cadastrar Usuário";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            this.ResumeLayout(false);

        }    

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.TextBox txbUsuario;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txbSenha;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lblv;
        private System.Windows.Forms.Button btnCads;
        private System.Windows.Forms.ToolTip ttpVoltar;
    }
}