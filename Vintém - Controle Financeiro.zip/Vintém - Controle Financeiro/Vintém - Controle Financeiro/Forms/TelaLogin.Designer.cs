﻿using System;

namespace Vintém___Controle_Financeiro
{
    partial class TelaLogin
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaLogin));
            this.pnl1 = new System.Windows.Forms.Panel();
            this.pctbSenha = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txbSenha = new System.Windows.Forms.TextBox();
            this.txbUsuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lblv = new System.Windows.Forms.Label();
            this.ttpNovo = new System.Windows.Forms.ToolTip(this.components);
            this.ttpSenha = new System.Windows.Forms.ToolTip(this.components);
            this.pctbCadastro = new System.Windows.Forms.PictureBox();
            this.pnl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbSenha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbCadastro)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl1.Controls.Add(this.pctbSenha);
            this.pnl1.Controls.Add(this.pctbCadastro);
            this.pnl1.Controls.Add(this.pictureBox2);
            this.pnl1.Controls.Add(this.pictureBox1);
            this.pnl1.Controls.Add(this.txbSenha);
            this.pnl1.Controls.Add(this.txbUsuario);
            this.pnl1.Controls.Add(this.label1);
            this.pnl1.Controls.Add(this.lbl3);
            this.pnl1.Controls.Add(this.btnLogin);
            this.pnl1.Controls.Add(this.lbl2);
            this.pnl1.Controls.Add(this.lblv);
            this.pnl1.Location = new System.Drawing.Point(0, 0);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(452, 301);
            this.pnl1.TabIndex = 0;
            // 
            // pctbSenha
            // 
            this.pctbSenha.Cursor = System.Windows.Forms.Cursors.Help;
            this.pctbSenha.Image = ((System.Drawing.Image)(resources.GetObject("pctbSenha.Image")));
            this.pctbSenha.Location = new System.Drawing.Point(405, 263);
            this.pctbSenha.Name = "pctbSenha";
            this.pctbSenha.Size = new System.Drawing.Size(34, 35);
            this.pctbSenha.TabIndex = 18;
            this.pctbSenha.TabStop = false;
            this.pctbSenha.Click += new System.EventHandler(this.PctbSenha_Click);
            this.pctbSenha.MouseEnter += new System.EventHandler(this.PctbSenha_MouseEnter);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(405, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(34, 35);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 35);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // txbSenha
            // 
            this.txbSenha.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSenha.Location = new System.Drawing.Point(180, 140);
            this.txbSenha.Name = "txbSenha";
            this.txbSenha.PasswordChar = '*';
            this.txbSenha.Size = new System.Drawing.Size(123, 22);
            this.txbSenha.TabIndex = 12;
            // 
            // txbUsuario
            // 
            this.txbUsuario.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbUsuario.Location = new System.Drawing.Point(180, 104);
            this.txbUsuario.Name = "txbUsuario";
            this.txbUsuario.Size = new System.Drawing.Size(123, 22);
            this.txbUsuario.TabIndex = 11;
            this.txbUsuario.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxbUsuario_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(41, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Gerencie seu dinheiro: mude sua vida";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(92, 137);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(68, 23);
            this.lbl3.TabIndex = 8;
            this.lbl3.Text = "Senha:";
            // 
            // btnLogin
            // 
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(205, 177);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(72, 25);
            this.btnLogin.TabIndex = 7;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(92, 101);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(83, 23);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Usuário:";
            // 
            // lblv
            // 
            this.lblv.AutoSize = true;
            this.lblv.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblv.ForeColor = System.Drawing.Color.Gold;
            this.lblv.Location = new System.Drawing.Point(3, 2);
            this.lblv.Name = "lblv";
            this.lblv.Size = new System.Drawing.Size(450, 32);
            this.lblv.TabIndex = 0;
            this.lblv.Text = "Vintém - Controle Financeiro";
            this.lblv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pctbCadastro
            // 
            this.pctbCadastro.Cursor = System.Windows.Forms.Cursors.Help;
            this.pctbCadastro.Image = ((System.Drawing.Image)(resources.GetObject("pctbCadastro.Image")));
            this.pctbCadastro.Location = new System.Drawing.Point(365, 263);
            this.pctbCadastro.Name = "pctbCadastro";
            this.pctbCadastro.Size = new System.Drawing.Size(34, 35);
            this.pctbCadastro.TabIndex = 17;
            this.pctbCadastro.TabStop = false;
            this.pctbCadastro.Click += new System.EventHandler(this.PctbCadastro_Click);
            this.pctbCadastro.MouseEnter += new System.EventHandler(this.PctbCadastro_MouseEnter);
            // 
            // TelaLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 299);
            this.Controls.Add(this.pnl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vintém - Login";
            this.Shown += new System.EventHandler(this.FormInic_Shown);
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbSenha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbCadastro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label lblv;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbUsuario;
        private System.Windows.Forms.TextBox txbSenha;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pctbSenha;
        private System.Windows.Forms.ToolTip ttpNovo;
        private System.Windows.Forms.ToolTip ttpSenha;
        private System.Windows.Forms.PictureBox pctbCadastro;
    }
}

