﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public struct Data
    {
        public int dia;
        public int mes;
        public int ano;
    }

    public partial class TelaExt : Form
    {
        string usuário, nomeContF;
        ArrayList MeusLançamentos = new ArrayList();
        ArrayList DGV = new ArrayList();
        ArrayList DGVnovo = new ArrayList();
        gerCTC Lanc = new gerCTC();

        public TelaExt(string usu, string nomeCF)
        {
            InitializeComponent();
            usuário = usu;
            nomeContF = nomeCF;
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaMovCCrr Nova = new TelaMovCCrr(nomeContF, usuário);
            Hide();
            Nova.Show();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            dgvUL.DataSource = null;

            mtbDataFin.Text = "";
            mtbDatainic.Text = "";
            MeusLançamentos.Clear();
            DGV.Clear();
        }

        private void btnPesq_Click(object sender, EventArgs e)
        {
            string DataInicial;
            string DataFinal;

            DataInicial = mtbDatainic.Text;
            DataFinal = mtbDataFin.Text;

            MeusLançamentos = Lanc.LerDados();

            DGV.Clear();
            DGVnovo.Clear();

            if (MeusLançamentos.Count != 0)
            {
                foreach (Lançamento x in MeusLançamentos)
                {
                    if (x.NomeCF == nomeContF)
                    {
                        DGV.Add(x);                      
                    }
                }
            }

            foreach(Lançamento x in DGV)
            {                
                DateTime dataInic;
                DateTime dataFin;
                DateTime dataLanc;

                dataInic = Convert.ToDateTime(mtbDatainic.Text);
                dataFin = Convert.ToDateTime(mtbDataFin.Text);
                dataLanc = Convert.ToDateTime(x.DataLanc);

                if ((ComparaData(dataLanc, dataInic) >= 0) && (ComparaData(dataLanc, dataFin) <= 0))
                {
                    DGVnovo.Add(x);
                }               
            }

            dgvUL.DataSource = DGVnovo;
        }

        public int ComparaData(DateTime data1, DateTime data2)
        {
            return DateTime.Compare(data1, data2);
        }
    }
}
