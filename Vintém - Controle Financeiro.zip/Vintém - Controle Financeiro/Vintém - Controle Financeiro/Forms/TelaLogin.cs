﻿using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;
using Vintém___Controle_Financeiro.Classes;
using Vintém___Controle_Financeiro.Forms;

namespace Vintém___Controle_Financeiro
{
    public partial class TelaLogin : Form
    {
        public TelaLogin()
        {
            InitializeComponent();
        }

        private void FormInic_Shown(object sender, EventArgs e)
        {
            txbUsuario.Focus();
        }

        private void TxbUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab | e.KeyCode == Keys.Enter)
            {
                txbSenha.Focus();

            }
            else if (txbSenha.Focused)
            {

            }
        }

        private void PctbCadastro_MouseEnter(object sender, EventArgs e)
        {
            ttpNovo.SetToolTip(pctbCadastro, "Cadastrar Usuário");
        }

        private void PctbSenha_MouseEnter(object sender, EventArgs e)
        {
            ttpNovo.SetToolTip(pctbSenha, "Alterar Senha");
        }

        private void PctbCadastro_Click(object sender, EventArgs e)
        {
            TelaCads telaNova = new TelaCads();

            this.Hide();

            telaNova.ShowDialog();
        }

        private void PctbSenha_Click(object sender, EventArgs e)
        {
            TelaRecSenha telaNova = new TelaRecSenha();

            this.Hide();

            telaNova.ShowDialog();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            OperaçõesLogin MinhaOperação = new OperaçõesLogin();
            ControleFinanc MeuControle = new ControleFinanc();

            ArrayList Lista = MeuControle.LerDados();

            if (MinhaOperação.FazLogin(txbUsuario.Text, txbSenha.Text) == 1)
            {
                if (MeuControle.VerificaControle(txbUsuario.Text) == true)
                {
                    foreach(ObjetoControle x in Lista)
                    {
                        if(x.NomeUsu == txbUsuario.Text)
                        {
                            CFInicial1 NovaTela = new CFInicial1(txbUsuario.Text,x.NomeCF);
                            Hide();
                            NovaTela.Show();
                        }
                    }
                    
                }
                else
                {
                    CFInicial NovaTela = new CFInicial(txbUsuario.Text);
                    Hide();
                    NovaTela.Show();
                }              
            }
            else if(MinhaOperação.FazLogin(txbUsuario.Text, txbSenha.Text) == 2)
            {
                MessageBox.Show("Usuário ou senha incorretos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                txbUsuario.Clear();
                txbSenha.Clear();
                txbUsuario.Focus();
            }
            else if (MinhaOperação.FazLogin(txbUsuario.Text, txbSenha.Text) == 3)
            {
                MessageBox.Show("Usuário não existe!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                txbUsuario.Clear();
                txbSenha.Clear();
                txbUsuario.Focus();
            }
        }
    }
}
      
