﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaRelatório : Form
    {
        string usuário, nomeCf;

        ArrayList MinhasMovs = new ArrayList();
        gerCTC Lanc = new gerCTC();
        ArrayList DGV = new ArrayList();
        ArrayList TipoValor = new ArrayList();

        public TelaRelatório(string usu, string nomeCF)
        {
            InitializeComponent();
            usuário = usu;
            nomeCf = nomeCF;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cbbRelat_SelectedValueChanged(object sender, EventArgs e)
        {
            if(cbbRelat.SelectedItem.ToString() == "Por tipo de movimentação")
            {
                dgvUL.DataSource = null;
                lblValor.Visible = false;
                rtbValor.Visible = false;
                rdbMaiorEnt.Visible = false;
                rdbMenorEnt.Visible = false;
                rdbMaiorSai.Visible = false;
                rdbMenorSai.Visible = false;

                lblTipo.Visible = true;
                cbbTipo.Visible = true;

            }else if(cbbRelat.SelectedItem.ToString() == "Por valor de movimentação")
            {
                dgvUL.DataSource = null;
                lblTipo.Visible = false;
                cbbTipo.Visible = false;

                lblValor.Visible = true;
                rtbValor.Visible = true;
                rdbMaiorEnt.Visible = true;
                rdbMenorEnt.Visible = true;
                rdbMaiorSai.Visible = true;
                rdbMenorSai.Visible = true;
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (cbbRelat.SelectedItem.ToString() == "Por tipo de movimentação")
            {
                dgvUL.DataSource = null;
                PorTipoMov();
            }
            else if (cbbRelat.SelectedItem.ToString() == "Por valor de movimentação")
            {
                dgvUL.DataSource = null;
                PorValorMov();
            }
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaPrincipal NovaT = new TelaPrincipal(usuário, nomeCf);
            Hide();
            NovaT.Show();
        }

        private void PorTipoMov()
        {
            MinhasMovs = Lanc.LerDados();

            DGV.Clear();
            if (MinhasMovs.Count != 0)
            {
                foreach (Lançamento x in MinhasMovs)
                {
                    if (x.NomeCF == nomeCf)
                    {
                        DGV.Add(x);
                    }
                }
            }

            string tipo;

            tipo = cbbTipo.Text;

            if(tipo == "Todos os Tipos")
            {
                dgvUL.Visible = true;
                dgvUL.DataSource = DGV;
            }
            else
            {
                dgvUL.DataSource = null;

                TipoValor.Clear();
                foreach(Lançamento x in DGV)
                {
                    if(x.TipoLanc == tipo)
                    {
                        TipoValor.Add(x);
                    }
                }

                dgvUL.Visible = true;
                dgvUL.DataSource = TipoValor;
            }

        }

        private void PorValorMov()
        {
            MinhasMovs.Clear();
            MinhasMovs = Lanc.LerDados();

            DGV.Clear();
            if (MinhasMovs.Count != 0)
            {
                foreach (Lançamento x in MinhasMovs)
                {
                    if (x.NomeCF == nomeCf)
                    {
                        DGV.Add(x);
                    }
                }
            }

            double valor;
            valor = double.Parse(rtbValor.Text);

            if (rdbMaiorEnt.Checked)
            {
                dgvUL.DataSource = null;

                TipoValor.Clear();
                foreach (Lançamento x in DGV)
                {
                    if (x.ValorLanc >= valor && x.ValorLanc >= 0)
                    {
                        TipoValor.Add(x);
                    }
                }

                dgvUL.Visible = true;
                dgvUL.DataSource = TipoValor;
            }
            else if (rdbMenorEnt.Checked)
            {
                dgvUL.DataSource = null;

                TipoValor.Clear();
                foreach (Lançamento x in DGV)
                {
                    if (x.ValorLanc <= valor && x.ValorLanc >= 0)
                    {
                        TipoValor.Add(x);
                    }
                }

                dgvUL.Visible = true;
                dgvUL.DataSource = TipoValor;

            }else if (rdbMaiorSai.Checked)
            {
                dgvUL.DataSource = null;

                TipoValor.Clear();
                foreach (Lançamento x in DGV)
                {
                    if (+x.ValorLanc >= valor && x.ValorLanc <= 0)
                    {
                        TipoValor.Add(x);
                    }
                }

                dgvUL.Visible = true;
                dgvUL.DataSource = TipoValor;

            }else if (rdbMenorSai.Checked)
            {
                dgvUL.DataSource = null;

                TipoValor.Clear();
                foreach (Lançamento x in DGV)
                {
                    if (+x.ValorLanc <= valor && x.ValorLanc <= 0)
                    {
                        TipoValor.Add(x);
                    }
                }

                dgvUL.Visible = true;
                dgvUL.DataSource = TipoValor;
            }

        }
    }
}
