﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaCads : Form
    {
        OperaçõesLogin MinhaOperação = new OperaçõesLogin();

        public TelaCads()
        {
            InitializeComponent();            
        }

        private void pctbVoltar_MouseEnter(object sender, EventArgs e)
        {
            ttpVoltar.SetToolTip(pctbVoltar, "Voltar");
        }

        private void PctbVoltar_Click(object sender, EventArgs e)
        {
            TelaLogin telaNova = new TelaLogin();

            this.Hide();

            telaNova.ShowDialog();
        }

        private void btnCads_Click(object sender, EventArgs e)
        {
            MinhaOperação.FazCadastro(txbUsuario.Text, txbSenha.Text);

            txbUsuario.Clear();
            txbSenha.Clear();
            txbUsuario.Focus();
        }
    }
}
