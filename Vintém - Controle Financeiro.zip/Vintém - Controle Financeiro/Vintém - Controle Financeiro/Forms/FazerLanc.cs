﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class FazerLanc : Form
    {
        string usuário, NomeCF;

        gerCTC MeuLançamento;
        public FazerLanc(string usu, string nomeCF)
        {
            InitializeComponent();
            usuário = usu;
            NomeCF = nomeCF;
            MeuLançamento = new gerCTC();
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaMovCCrr Nova = new TelaMovCCrr(NomeCF, usuário);
            Hide();
            Nova.Show();
        }

        private void RtbValor_Enter(object sender, EventArgs e)
        {
            ttpCampo.SetToolTip(rtbValor, "Use o . para adicionar centavos");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            double valor = 0;
            string tipo;
            string data;
    
            tipo = cbbTipo.Text;
            data = mtbData.Text;

            if (rdbEnt.Checked)
            {
                valor = +double.Parse(rtbValor.Text);

            }else if (rdbSai.Checked)
            {
                valor = -double.Parse(rtbValor.Text);
            }

            MeuLançamento.FazLançamento(valor, tipo, data, NomeCF);
            MessageBox.Show("Lançamento feito com sucesso!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            rdbEnt.Checked = false;
            rdbSai.Checked = false;
            rtbValor.Clear();
            cbbTipo.ResetText();
            mtbData.Clear();
        }
    }
}
