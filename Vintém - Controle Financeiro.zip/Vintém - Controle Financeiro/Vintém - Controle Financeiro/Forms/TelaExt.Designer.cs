﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaExt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaExt));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnPesq = new System.Windows.Forms.Button();
            this.mtbDatainic = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mtbDataFin = new System.Windows.Forms.MaskedTextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lançamentoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvUL = new System.Windows.Forms.DataGridView();
            this.códLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPesq
            // 
            this.btnPesq.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesq.Location = new System.Drawing.Point(512, 42);
            this.btnPesq.Name = "btnPesq";
            this.btnPesq.Size = new System.Drawing.Size(75, 23);
            this.btnPesq.TabIndex = 39;
            this.btnPesq.Text = "Pesquisar";
            this.btnPesq.UseVisualStyleBackColor = true;
            this.btnPesq.Click += new System.EventHandler(this.btnPesq_Click);
            // 
            // mtbDatainic
            // 
            this.mtbDatainic.Location = new System.Drawing.Point(147, 47);
            this.mtbDatainic.Mask = "00/00/0000";
            this.mtbDatainic.Name = "mtbDatainic";
            this.mtbDatainic.Size = new System.Drawing.Size(110, 20);
            this.mtbDatainic.TabIndex = 38;
            this.mtbDatainic.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtbDatainic.ValidatingType = typeof(System.DateTime);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 37;
            this.label4.Text = "Data inicial:";
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(-1, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 42;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(143, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(293, 23);
            this.label2.TabIndex = 41;
            this.label2.Text = "Extrato de Conta Corrente";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 15);
            this.label1.TabIndex = 43;
            this.label1.Text = "Data final:";
            // 
            // mtbDataFin
            // 
            this.mtbDataFin.Location = new System.Drawing.Point(351, 44);
            this.mtbDataFin.Mask = "00/00/0000";
            this.mtbDataFin.Name = "mtbDataFin";
            this.mtbDataFin.Size = new System.Drawing.Size(110, 20);
            this.mtbDataFin.TabIndex = 44;
            this.mtbDataFin.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtbDataFin.ValidatingType = typeof(System.DateTime);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(512, 71);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 45;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lançamentoBindingSource
            // 
            this.lançamentoBindingSource.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // dgvUL
            // 
            this.dgvUL.AllowUserToAddRows = false;
            this.dgvUL.AllowUserToDeleteRows = false;
            this.dgvUL.AllowUserToOrderColumns = true;
            this.dgvUL.AllowUserToResizeColumns = false;
            this.dgvUL.AllowUserToResizeRows = false;
            this.dgvUL.AutoGenerateColumns = false;
            this.dgvUL.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = "0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.códLanc,
            this.dataLanc,
            this.valorLanc,
            this.tipoLanc});
            this.dgvUL.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvUL.DataSource = this.lançamentoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvUL.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvUL.Location = new System.Drawing.Point(65, 73);
            this.dgvUL.MultiSelect = false;
            this.dgvUL.Name = "dgvUL";
            this.dgvUL.ReadOnly = true;
            this.dgvUL.RowHeadersWidth = 4;
            this.dgvUL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvUL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUL.ShowCellErrors = false;
            this.dgvUL.ShowCellToolTips = false;
            this.dgvUL.ShowEditingIcon = false;
            this.dgvUL.ShowRowErrors = false;
            this.dgvUL.Size = new System.Drawing.Size(396, 336);
            this.dgvUL.TabIndex = 46;
            this.dgvUL.TabStop = false;
            // 
            // códLanc
            // 
            this.códLanc.DataPropertyName = "CódLanc";
            this.códLanc.HeaderText = "Código";
            this.códLanc.Name = "códLanc";
            this.códLanc.ReadOnly = true;
            this.códLanc.Width = 80;
            // 
            // dataLanc
            // 
            this.dataLanc.DataPropertyName = "DataLanc";
            this.dataLanc.HeaderText = "Data";
            this.dataLanc.Name = "dataLanc";
            this.dataLanc.ReadOnly = true;
            // 
            // valorLanc
            // 
            this.valorLanc.DataPropertyName = "ValorLanc";
            this.valorLanc.HeaderText = "Valor";
            this.valorLanc.Name = "valorLanc";
            this.valorLanc.ReadOnly = true;
            // 
            // tipoLanc
            // 
            this.tipoLanc.DataPropertyName = "TipoLanc";
            this.tipoLanc.HeaderText = "Tipo";
            this.tipoLanc.Name = "tipoLanc";
            this.tipoLanc.ReadOnly = true;
            this.tipoLanc.Width = 110;
            // 
            // TelaExt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 417);
            this.Controls.Add(this.dgvUL);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.mtbDataFin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pctbVoltar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPesq);
            this.Controls.Add(this.mtbDatainic);
            this.Controls.Add(this.label4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaExt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Extrato";
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPesq;
        private System.Windows.Forms.MaskedTextBox mtbDatainic;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mtbDataFin;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.BindingSource lançamentoBindingSource;
        private System.Windows.Forms.DataGridView dgvUL;
        private System.Windows.Forms.DataGridViewTextBoxColumn códLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoLanc;
    }
}