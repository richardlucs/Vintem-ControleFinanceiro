﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class AltLanc : Form
    {
        string usuário, nomeContF;
        ArrayList MeusLançamentos = new ArrayList();
        ArrayList MeusLançamentosNovo = new ArrayList();

        Lançamento ObjetoLancNovo = new Lançamento();
        Lançamento ObjetoLancVelho = new Lançamento();
        ArrayList DGV = new ArrayList();
        gerCTC Lanc = new gerCTC();
        string cód;

        public AltLanc(string usu, string nomeCF)
        {
            InitializeComponent();
            usuário = usu;
            nomeContF = nomeCF;
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaMovCCrr Nova = new TelaMovCCrr(nomeContF, usuário);
            Hide();
            Nova.Show();
        }

        private void AltLanc_Load(object sender, EventArgs e)
        {
            MeusLançamentos = Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (x.NomeCF == nomeContF)
                {
                    DGV.Add(x);
                }
            }

            dgvUL.DataSource = DGV;

        }

        private void dgvUL_SelectionChanged(object sender, EventArgs e)
        {
            MeusLançamentos.Clear();
            MeusLançamentos = Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (dgvUL.CurrentRow.Cells[0].Value.ToString() == x.CódLanc)
                {
                    rtbValor.Text = x.ValorLanc.ToString();
                    cbbTipo.Text = x.TipoLanc;
                    mtbData.Text = x.DataLanc;

                    cód = x.CódLanc;
                    ObjetoLancVelho.CódLanc = x.CódLanc;
                    ObjetoLancVelho.ValorLanc = x.ValorLanc;
                    ObjetoLancVelho.TipoLanc = x.TipoLanc;
                    ObjetoLancVelho.DataLanc = x.DataLanc;
                    ObjetoLancVelho.NomeCF = x.NomeCF;
                    break;
                }
            }
        }

        private void btnAlt_Click(object sender, EventArgs e)
        {
            foreach (Lançamento x in MeusLançamentos)
            {
                if (dgvUL.CurrentRow.Cells[0].Value.ToString() != x.CódLanc)
                {
                    MeusLançamentosNovo.Add(x);
                }
                else
                {
                    ObjetoLancNovo.CódLanc = cód;
                    ObjetoLancNovo.ValorLanc = double.Parse(rtbValor.Text);
                    ObjetoLancNovo.TipoLanc = cbbTipo.Text;
                    ObjetoLancNovo.DataLanc = mtbData.Text;
                    ObjetoLancNovo.NomeCF = nomeContF;

                    MeusLançamentosNovo.Add(ObjetoLancNovo);
                    break;
                }              
            }

            Lanc.GravaDados(MeusLançamentosNovo);

            CarregaGrid();
        }

        public void CarregaGrid()
        {
            dgvUL.DataSource = null;

            MeusLançamentos.Clear();
            DGV.Clear();

            Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (x.NomeCF == nomeContF)
                {
                    DGV.Add(x);
                }
            }

            dgvUL.DataSource = DGV;
        }
    }
}
