﻿using System;

namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaRecSenha1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaRecSenha1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAlt = new System.Windows.Forms.Button();
            this.txbSenhaC = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lblv = new System.Windows.Forms.Label();
            this.txbSenhaN = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.ttpVoltar = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.btnAlt);
            this.panel1.Controls.Add(this.txbSenhaC);
            this.panel1.Controls.Add(this.lbl3);
            this.panel1.Controls.Add(this.lblv);
            this.panel1.Controls.Add(this.txbSenhaN);
            this.panel1.Controls.Add(this.lbl2);
            this.panel1.Controls.Add(this.pctbVoltar);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 298);
            this.panel1.TabIndex = 1;
            // 
            // btnAlt
            // 
            this.btnAlt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlt.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlt.Location = new System.Drawing.Point(211, 176);
            this.btnAlt.Name = "btnAlt";
            this.btnAlt.Size = new System.Drawing.Size(82, 25);
            this.btnAlt.TabIndex = 31;
            this.btnAlt.Text = "Alterar";
            this.btnAlt.UseVisualStyleBackColor = true;
            this.btnAlt.Click += new System.EventHandler(this.btnAlt_Click);
            // 
            // txbSenhaC
            // 
            this.txbSenhaC.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSenhaC.Location = new System.Drawing.Point(192, 139);
            this.txbSenhaC.Name = "txbSenhaC";
            this.txbSenhaC.PasswordChar = '*';
            this.txbSenhaC.Size = new System.Drawing.Size(123, 22);
            this.txbSenhaC.TabIndex = 30;
            this.txbSenhaC.Validating += new System.ComponentModel.CancelEventHandler(this.txbSenhaC_Validating);
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(25, 136);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(164, 23);
            this.lbl3.TabIndex = 29;
            this.lbl3.Text = "Confirme a senha:";
            // 
            // lblv
            // 
            this.lblv.AutoSize = true;
            this.lblv.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblv.ForeColor = System.Drawing.Color.Gold;
            this.lblv.Location = new System.Drawing.Point(51, 9);
            this.lblv.Name = "lblv";
            this.lblv.Size = new System.Drawing.Size(395, 32);
            this.lblv.TabIndex = 28;
            this.lblv.Text = "Recuperar/Alterar Senha";
            this.lblv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txbSenhaN
            // 
            this.txbSenhaN.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSenhaN.Location = new System.Drawing.Point(192, 98);
            this.txbSenhaN.Name = "txbSenhaN";
            this.txbSenhaN.PasswordChar = '*';
            this.txbSenhaN.Size = new System.Drawing.Size(123, 22);
            this.txbSenhaN.TabIndex = 27;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(76, 95);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(113, 23);
            this.lbl2.TabIndex = 26;
            this.lbl2.Text = "Senha nova:";
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 19;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.PctbVoltar_Click);
            this.pctbVoltar.MouseEnter += new System.EventHandler(this.PctbVoltar_MouseEnter);
            // 
            // TelaRecSenha1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 299);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaRecSenha1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vintém - Alterar Senha";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            this.ResumeLayout(false);

        }      

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.Label lblv;
        private System.Windows.Forms.TextBox txbSenhaN;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Button btnAlt;
        private System.Windows.Forms.TextBox txbSenhaC;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.ToolTip ttpVoltar;
    }
}