﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaRecSenha1 : Form
    {
        string MeuUsu;

        public TelaRecSenha1(string texto)
        {
            InitializeComponent();

            MeuUsu = texto;
        }

        private void PctbVoltar_MouseEnter(object sender, EventArgs e)
        {
            ttpVoltar.SetToolTip(pctbVoltar, "Voltar");
        }

        private void PctbVoltar_Click(object sender, EventArgs e)
        {
            TelaLogin telaNova = new TelaLogin();

            this.Hide();

            telaNova.ShowDialog();
        }

        private void btnAlt_Click(object sender, EventArgs e)
        {
            OperaçõesLogin MinhaOperação = new OperaçõesLogin();

            MinhaOperação.TrocaSenha(txbSenhaN.Text, txbSenhaC.Text,MeuUsu);

            TelaLogin TelaNova = new TelaLogin();
            Hide();
            TelaNova.Show();
        }

        private void txbSenhaC_Validating(object sender, CancelEventArgs e)
        {
            if (txbSenhaN.Text != txbSenhaC.Text)
            {
                MessageBox.Show("As senhas não correspondem!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
        }
    }
}
