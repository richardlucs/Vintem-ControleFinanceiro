﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaRelatório
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaRelatório));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.cbbRelat = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.cbbTipo = new System.Windows.Forms.ComboBox();
            this.rtbValor = new System.Windows.Forms.RichTextBox();
            this.lblValor = new System.Windows.Forms.Label();
            this.rdbMaiorEnt = new System.Windows.Forms.RadioButton();
            this.rdbMenorEnt = new System.Windows.Forms.RadioButton();
            this.dgvUL = new System.Windows.Forms.DataGridView();
            this.btnOk = new System.Windows.Forms.Button();
            this.códLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lançamentoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.lançamentoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rdbMaiorSai = new System.Windows.Forms.RadioButton();
            this.rdbMenorSai = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 22;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // cbbRelat
            // 
            this.cbbRelat.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbRelat.Items.AddRange(new object[] {
            "Por tipo de movimentação",
            "Por valor de movimentação"});
            this.cbbRelat.Location = new System.Drawing.Point(206, 46);
            this.cbbRelat.Name = "cbbRelat";
            this.cbbRelat.Size = new System.Drawing.Size(219, 24);
            this.cbbRelat.TabIndex = 23;
            this.cbbRelat.SelectedValueChanged += new System.EventHandler(this.cbbRelat_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(160, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 23);
            this.label1.TabIndex = 24;
            this.label1.Text = "Relatório - Conta Corrente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(134, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 18);
            this.label2.TabIndex = 25;
            this.label2.Text = "Dados:";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(220, 89);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(42, 16);
            this.lblTipo.TabIndex = 31;
            this.lblTipo.Text = "Tipo:";
            this.lblTipo.Visible = false;
            this.lblTipo.Click += new System.EventHandler(this.label3_Click);
            // 
            // cbbTipo
            // 
            this.cbbTipo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbTipo.FormattingEnabled = true;
            this.cbbTipo.Items.AddRange(new object[] {
            "Salário",
            "Transferência",
            "Alimentação",
            "Transporte",
            "Lazer",
            "Saúde",
            "Vestuário",
            "Educação",
            "Contas",
            "Outros",
            "Saque",
            "Todos os Tipos"});
            this.cbbTipo.Location = new System.Drawing.Point(262, 85);
            this.cbbTipo.Name = "cbbTipo";
            this.cbbTipo.Size = new System.Drawing.Size(138, 24);
            this.cbbTipo.TabIndex = 30;
            this.cbbTipo.Visible = false;
            // 
            // rtbValor
            // 
            this.rtbValor.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbValor.Location = new System.Drawing.Point(184, 87);
            this.rtbValor.Name = "rtbValor";
            this.rtbValor.Size = new System.Drawing.Size(110, 22);
            this.rtbValor.TabIndex = 33;
            this.rtbValor.Text = "";
            this.rtbValor.Visible = false;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(134, 91);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(44, 14);
            this.lblValor.TabIndex = 32;
            this.lblValor.Text = "Valor:";
            this.lblValor.Visible = false;
            // 
            // rdbMaiorEnt
            // 
            this.rdbMaiorEnt.AutoSize = true;
            this.rdbMaiorEnt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMaiorEnt.Location = new System.Drawing.Point(300, 76);
            this.rdbMaiorEnt.Name = "rdbMaiorEnt";
            this.rdbMaiorEnt.Size = new System.Drawing.Size(150, 18);
            this.rdbMaiorEnt.TabIndex = 34;
            this.rdbMaiorEnt.TabStop = true;
            this.rdbMaiorEnt.Text = "Maior que - Entrada";
            this.rdbMaiorEnt.UseVisualStyleBackColor = true;
            this.rdbMaiorEnt.Visible = false;
            // 
            // rdbMenorEnt
            // 
            this.rdbMenorEnt.AutoSize = true;
            this.rdbMenorEnt.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMenorEnt.Location = new System.Drawing.Point(300, 100);
            this.rdbMenorEnt.Name = "rdbMenorEnt";
            this.rdbMenorEnt.Size = new System.Drawing.Size(155, 18);
            this.rdbMenorEnt.TabIndex = 35;
            this.rdbMenorEnt.TabStop = true;
            this.rdbMenorEnt.Text = "Menor que - Entrada";
            this.rdbMenorEnt.UseVisualStyleBackColor = true;
            this.rdbMenorEnt.Visible = false;
            // 
            // dgvUL
            // 
            this.dgvUL.AllowUserToAddRows = false;
            this.dgvUL.AllowUserToDeleteRows = false;
            this.dgvUL.AllowUserToResizeColumns = false;
            this.dgvUL.AllowUserToResizeRows = false;
            this.dgvUL.AutoGenerateColumns = false;
            this.dgvUL.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = "0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.códLancDataGridViewTextBoxColumn,
            this.dataLancDataGridViewTextBoxColumn,
            this.valorLancDataGridViewTextBoxColumn,
            this.tipoLancDataGridViewTextBoxColumn});
            this.dgvUL.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvUL.DataSource = this.lançamentoBindingSource1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvUL.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvUL.Location = new System.Drawing.Point(110, 148);
            this.dgvUL.MultiSelect = false;
            this.dgvUL.Name = "dgvUL";
            this.dgvUL.ReadOnly = true;
            this.dgvUL.RowHeadersWidth = 4;
            this.dgvUL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvUL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUL.ShowCellErrors = false;
            this.dgvUL.ShowCellToolTips = false;
            this.dgvUL.ShowEditingIcon = false;
            this.dgvUL.ShowRowErrors = false;
            this.dgvUL.Size = new System.Drawing.Size(396, 336);
            this.dgvUL.TabIndex = 47;
            this.dgvUL.TabStop = false;
            this.dgvUL.Visible = false;
            // 
            // btnOk
            // 
            this.btnOk.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.Location = new System.Drawing.Point(280, 119);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 48;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // códLancDataGridViewTextBoxColumn
            // 
            this.códLancDataGridViewTextBoxColumn.DataPropertyName = "CódLanc";
            this.códLancDataGridViewTextBoxColumn.HeaderText = "Código";
            this.códLancDataGridViewTextBoxColumn.Name = "códLancDataGridViewTextBoxColumn";
            this.códLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataLancDataGridViewTextBoxColumn
            // 
            this.dataLancDataGridViewTextBoxColumn.DataPropertyName = "DataLanc";
            this.dataLancDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataLancDataGridViewTextBoxColumn.Name = "dataLancDataGridViewTextBoxColumn";
            this.dataLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // valorLancDataGridViewTextBoxColumn
            // 
            this.valorLancDataGridViewTextBoxColumn.DataPropertyName = "ValorLanc";
            this.valorLancDataGridViewTextBoxColumn.HeaderText = "Valor";
            this.valorLancDataGridViewTextBoxColumn.Name = "valorLancDataGridViewTextBoxColumn";
            this.valorLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tipoLancDataGridViewTextBoxColumn
            // 
            this.tipoLancDataGridViewTextBoxColumn.DataPropertyName = "TipoLanc";
            this.tipoLancDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoLancDataGridViewTextBoxColumn.Name = "tipoLancDataGridViewTextBoxColumn";
            this.tipoLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lançamentoBindingSource1
            // 
            this.lançamentoBindingSource1.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // lançamentoBindingSource
            // 
            this.lançamentoBindingSource.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // rdbMaiorSai
            // 
            this.rdbMaiorSai.AutoSize = true;
            this.rdbMaiorSai.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMaiorSai.Location = new System.Drawing.Point(456, 76);
            this.rdbMaiorSai.Name = "rdbMaiorSai";
            this.rdbMaiorSai.Size = new System.Drawing.Size(135, 18);
            this.rdbMaiorSai.TabIndex = 49;
            this.rdbMaiorSai.TabStop = true;
            this.rdbMaiorSai.Text = "Maior que - Saída";
            this.rdbMaiorSai.UseVisualStyleBackColor = true;
            this.rdbMaiorSai.Visible = false;
            // 
            // rdbMenorSai
            // 
            this.rdbMenorSai.AutoSize = true;
            this.rdbMenorSai.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMenorSai.Location = new System.Drawing.Point(456, 100);
            this.rdbMenorSai.Name = "rdbMenorSai";
            this.rdbMenorSai.Size = new System.Drawing.Size(140, 18);
            this.rdbMenorSai.TabIndex = 50;
            this.rdbMenorSai.TabStop = true;
            this.rdbMenorSai.Text = "Menor que - Saída";
            this.rdbMenorSai.UseVisualStyleBackColor = true;
            this.rdbMenorSai.Visible = false;
            // 
            // TelaRelatório
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(594, 496);
            this.Controls.Add(this.rdbMenorSai);
            this.Controls.Add(this.rdbMaiorSai);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.dgvUL);
            this.Controls.Add(this.rdbMenorEnt);
            this.Controls.Add(this.rdbMaiorEnt);
            this.Controls.Add(this.rtbValor);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.cbbTipo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbbRelat);
            this.Controls.Add(this.pctbVoltar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaRelatório";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Relatório de Conta Corrente";
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.ComboBox cbbRelat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.ComboBox cbbTipo;
        private System.Windows.Forms.RichTextBox rtbValor;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.RadioButton rdbMaiorEnt;
        private System.Windows.Forms.RadioButton rdbMenorEnt;
        private System.Windows.Forms.DataGridView dgvUL;
        private System.Windows.Forms.BindingSource lançamentoBindingSource;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.DataGridViewTextBoxColumn códLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource lançamentoBindingSource1;
        private System.Windows.Forms.RadioButton rdbMaiorSai;
        private System.Windows.Forms.RadioButton rdbMenorSai;
    }
}