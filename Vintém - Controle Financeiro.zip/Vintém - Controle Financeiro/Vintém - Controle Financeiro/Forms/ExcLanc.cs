﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class ExcLanc : Form
    {
        string usuário, NomeCF;
        ArrayList MeusLançamentos = new ArrayList();
        ArrayList DGV = new ArrayList();
        gerCTC Lanc = new gerCTC();

        public ExcLanc(string usu, string nomeCF) 
        {
            InitializeComponent();
            usuário = usu;
            NomeCF = nomeCF;         
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaMovCCrr Nova = new TelaMovCCrr(NomeCF, usuário);
            Hide();
            Nova.Show();
        }

        private void ExcLanc_Load(object sender, EventArgs e)
        {
            MeusLançamentos = Lanc.LerDados();

            if (MeusLançamentos.Count != 0)
            {
                foreach (Lançamento x in MeusLançamentos)
                {
                    if (x.NomeCF == NomeCF)
                    {
                        DGV.Add(x);
                    }
                }
                
                dgvUL.DataSource = DGV;
                
            }           
        }

        private void btnExc_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (Lançamento x in MeusLançamentos)
                {

                    if (dgvUL.CurrentRow.Cells[0].Value.ToString() == x.CódLanc)
                    {
                        MeusLançamentos.Remove(x);
                        DGV.Remove(x);
                        break;
                    }

                }
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Não há lançamentos para excluir!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            Lanc.GravaDados(MeusLançamentos);

            CarregaGrid();
        }

        private void CarregaGrid()
        { 
            dgvUL.DataSource = null;

            MeusLançamentos.Clear();
            DGV.Clear();

            Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (x.NomeCF == NomeCF)
                {
                    DGV.Add(x);
                }
            }          

            dgvUL.DataSource = DGV;    
        }
    }
}
