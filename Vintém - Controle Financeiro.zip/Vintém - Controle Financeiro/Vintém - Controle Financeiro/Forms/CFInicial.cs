﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class CFInicial : Form
    {
        string MeuUsu;

        public CFInicial(string texto)
        {
            InitializeComponent();
            MeuUsu = texto;
        }

        private void pctbAdicionar_Click(object sender, EventArgs e)
        {
            CFCriar NovaTela = new CFCriar(MeuUsu);

            Hide();

            NovaTela.Show();
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Tem certeza que deseja sair?", "Confirme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                TelaLogin Nova = new TelaLogin();
                Hide();
                Nova.Show();
            }
        }
    }
}
