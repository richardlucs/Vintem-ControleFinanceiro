﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class CFInicial1 : Form
    {
        string MeuUsuário;
        ControleFinanc MeuControle = new ControleFinanc();

        public CFInicial1(string usu, string NomeCF)
        {
            InitializeComponent();
            MeuUsuário = usu;
            lblNome.Text = NomeCF;
        }

        private void pctbAdicionar_Click(object sender, EventArgs e)
        {
            TelaPrincipal NovaP = new TelaPrincipal(MeuUsuário,lblNome.Text);

            Hide();

            NovaP.Show();
        }

        private void pctbExcluir_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Tem certeza que deseja excluir este controle?", "Confirme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                MeuControle.ExcluirControle(lblNome.Text);
                MessageBox.Show("Controle excluído!", "Feito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                CFInicial TelaNova = new CFInicial(MeuUsuário);
                Hide();
                TelaNova.Show();
            }           
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Tem certeza que deseja sair?", "Confirme", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if(result == DialogResult.Yes)
            {
                TelaLogin Nova = new TelaLogin();
                Hide();
                Nova.Show();
            }
        }
    }
}
