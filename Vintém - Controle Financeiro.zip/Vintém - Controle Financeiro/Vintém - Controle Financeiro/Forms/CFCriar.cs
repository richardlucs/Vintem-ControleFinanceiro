﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class CFCriar : Form
    {
        string MeuUsu;
        public CFCriar(string texto)
        {
            InitializeComponent();
            MeuUsu = texto;
        }

        private void btnCriar_Click(object sender, EventArgs e)
        {
            if (rtbNome.Text == null)
            {
                MessageBox.Show("O campo nome não pode ser vazio!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                ObjetoControle MeuControle = new ObjetoControle();

                MeuControle.NomeUsu = MeuUsu;
                MeuControle.NomeCF = rtbNome.Text;

                ControleFinanc MeuObjeto = new ControleFinanc();

                MeuObjeto.InserirControle(MeuControle);

                MessageBox.Show("Controle Financeiro criado!", "Feito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                CFInicial1 TelaNova = new CFInicial1(MeuUsu,MeuControle.NomeCF);
                Hide();
                TelaNova.Show();
            }       
        }
    }
}
