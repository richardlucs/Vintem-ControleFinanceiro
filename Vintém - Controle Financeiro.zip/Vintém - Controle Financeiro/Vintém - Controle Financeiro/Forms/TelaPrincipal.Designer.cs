﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPrincipal));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvUL = new System.Windows.Forms.DataGridView();
            this.códLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lançamentoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.pctbRelat = new System.Windows.Forms.PictureBox();
            this.lblSaldo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCCrr = new System.Windows.Forms.Button();
            this.ttpRelat = new System.Windows.Forms.ToolTip(this.components);
            this.ttpAgend = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbRelat)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.dgvUL);
            this.panel1.Controls.Add(this.pctbVoltar);
            this.panel1.Controls.Add(this.pctbRelat);
            this.panel1.Controls.Add(this.lblSaldo);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnCCrr);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(674, 538);
            this.panel1.TabIndex = 0;
            // 
            // dgvUL
            // 
            this.dgvUL.AllowUserToAddRows = false;
            this.dgvUL.AllowUserToDeleteRows = false;
            this.dgvUL.AllowUserToResizeColumns = false;
            this.dgvUL.AllowUserToResizeRows = false;
            this.dgvUL.AutoGenerateColumns = false;
            this.dgvUL.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = "0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.códLancDataGridViewTextBoxColumn,
            this.dataLancDataGridViewTextBoxColumn,
            this.valorLancDataGridViewTextBoxColumn,
            this.tipoLancDataGridViewTextBoxColumn});
            this.dgvUL.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvUL.DataSource = this.lançamentoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvUL.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvUL.Location = new System.Drawing.Point(162, 91);
            this.dgvUL.MultiSelect = false;
            this.dgvUL.Name = "dgvUL";
            this.dgvUL.ReadOnly = true;
            this.dgvUL.RowHeadersWidth = 4;
            this.dgvUL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvUL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUL.ShowCellErrors = false;
            this.dgvUL.ShowCellToolTips = false;
            this.dgvUL.ShowEditingIcon = false;
            this.dgvUL.ShowRowErrors = false;
            this.dgvUL.Size = new System.Drawing.Size(344, 336);
            this.dgvUL.TabIndex = 22;
            // 
            // códLancDataGridViewTextBoxColumn
            // 
            this.códLancDataGridViewTextBoxColumn.DataPropertyName = "CódLanc";
            this.códLancDataGridViewTextBoxColumn.HeaderText = "Código";
            this.códLancDataGridViewTextBoxColumn.Name = "códLancDataGridViewTextBoxColumn";
            this.códLancDataGridViewTextBoxColumn.ReadOnly = true;
            this.códLancDataGridViewTextBoxColumn.Width = 75;
            // 
            // dataLancDataGridViewTextBoxColumn
            // 
            this.dataLancDataGridViewTextBoxColumn.DataPropertyName = "DataLanc";
            this.dataLancDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataLancDataGridViewTextBoxColumn.Name = "dataLancDataGridViewTextBoxColumn";
            this.dataLancDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataLancDataGridViewTextBoxColumn.Width = 80;
            // 
            // valorLancDataGridViewTextBoxColumn
            // 
            this.valorLancDataGridViewTextBoxColumn.DataPropertyName = "ValorLanc";
            this.valorLancDataGridViewTextBoxColumn.HeaderText = "Valor";
            this.valorLancDataGridViewTextBoxColumn.Name = "valorLancDataGridViewTextBoxColumn";
            this.valorLancDataGridViewTextBoxColumn.ReadOnly = true;
            this.valorLancDataGridViewTextBoxColumn.Width = 85;
            // 
            // tipoLancDataGridViewTextBoxColumn
            // 
            this.tipoLancDataGridViewTextBoxColumn.DataPropertyName = "TipoLanc";
            this.tipoLancDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoLancDataGridViewTextBoxColumn.Name = "tipoLancDataGridViewTextBoxColumn";
            this.tipoLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lançamentoBindingSource
            // 
            this.lançamentoBindingSource.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 493);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 21;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // pctbRelat
            // 
            this.pctbRelat.Cursor = System.Windows.Forms.Cursors.Help;
            this.pctbRelat.Image = ((System.Drawing.Image)(resources.GetObject("pctbRelat.Image")));
            this.pctbRelat.Location = new System.Drawing.Point(637, 500);
            this.pctbRelat.Name = "pctbRelat";
            this.pctbRelat.Size = new System.Drawing.Size(34, 35);
            this.pctbRelat.TabIndex = 18;
            this.pctbRelat.TabStop = false;
            this.pctbRelat.Click += new System.EventHandler(this.pctbRelat_Click);
            this.pctbRelat.MouseEnter += new System.EventHandler(this.PctbRelat_MouseEnter);
            // 
            // lblSaldo
            // 
            this.lblSaldo.AutoSize = true;
            this.lblSaldo.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo.ForeColor = System.Drawing.Color.Gold;
            this.lblSaldo.Location = new System.Drawing.Point(291, 452);
            this.lblSaldo.Name = "lblSaldo";
            this.lblSaldo.Size = new System.Drawing.Size(109, 18);
            this.lblSaldo.TabIndex = 7;
            this.lblSaldo.Text = "R$ 1127,00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(241, 434);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Saldo em Conta Corrente";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(241, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Últimos Lançamentos";
            // 
            // btnCCrr
            // 
            this.btnCCrr.BackColor = System.Drawing.Color.Gold;
            this.btnCCrr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCCrr.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCCrr.FlatAppearance.BorderSize = 2;
            this.btnCCrr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCCrr.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCCrr.Location = new System.Drawing.Point(0, 0);
            this.btnCCrr.Name = "btnCCrr";
            this.btnCCrr.Size = new System.Drawing.Size(672, 58);
            this.btnCCrr.TabIndex = 0;
            this.btnCCrr.TabStop = false;
            this.btnCCrr.Text = "Movimentações Conta Corrente\r\n(Débito)";
            this.btnCCrr.UseVisualStyleBackColor = false;
            this.btnCCrr.Click += new System.EventHandler(this.btnCCrr_Click);
            // 
            // TelaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 536);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tela Principal";
            this.Load += new System.EventHandler(this.TelaPrincipal_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbRelat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCCrr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSaldo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pctbRelat;
        private System.Windows.Forms.ToolTip ttpRelat;
        private System.Windows.Forms.ToolTip ttpAgend;
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.DataGridView dgvUL;
        private System.Windows.Forms.BindingSource lançamentoBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn códLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoLancDataGridViewTextBoxColumn;
    }
}