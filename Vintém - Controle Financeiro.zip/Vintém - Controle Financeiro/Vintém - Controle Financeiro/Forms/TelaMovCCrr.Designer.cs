﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class TelaMovCCrr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaMovCCrr));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.btnAlt = new System.Windows.Forms.Button();
            this.btnExt = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnFazerLanc = new System.Windows.Forms.Button();
            this.lblSaldo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvUL = new System.Windows.Forms.DataGridView();
            this.códLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoLanc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lançamentoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pctbVoltar);
            this.panel1.Controls.Add(this.btnAlt);
            this.panel1.Controls.Add(this.btnExt);
            this.panel1.Controls.Add(this.btnExcluir);
            this.panel1.Controls.Add(this.btnFazerLanc);
            this.panel1.Controls.Add(this.lblSaldo);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dgvUL);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(648, 435);
            this.panel1.TabIndex = 0;
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 21;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // btnAlt
            // 
            this.btnAlt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlt.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlt.Location = new System.Drawing.Point(468, 246);
            this.btnAlt.Name = "btnAlt";
            this.btnAlt.Size = new System.Drawing.Size(142, 25);
            this.btnAlt.TabIndex = 13;
            this.btnAlt.Text = "Alterar Lançamento";
            this.btnAlt.UseVisualStyleBackColor = true;
            this.btnAlt.Click += new System.EventHandler(this.btnAlt_Click);
            // 
            // btnExt
            // 
            this.btnExt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExt.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExt.Location = new System.Drawing.Point(468, 277);
            this.btnExt.Name = "btnExt";
            this.btnExt.Size = new System.Drawing.Size(142, 25);
            this.btnExt.TabIndex = 12;
            this.btnExt.Text = "Extrato";
            this.btnExt.UseVisualStyleBackColor = true;
            this.btnExt.Click += new System.EventHandler(this.btnExt_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Location = new System.Drawing.Point(468, 215);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(142, 25);
            this.btnExcluir.TabIndex = 11;
            this.btnExcluir.Text = "Excluir Lançamento";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnFazerLanc
            // 
            this.btnFazerLanc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFazerLanc.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFazerLanc.Location = new System.Drawing.Point(468, 184);
            this.btnFazerLanc.Name = "btnFazerLanc";
            this.btnFazerLanc.Size = new System.Drawing.Size(142, 25);
            this.btnFazerLanc.TabIndex = 10;
            this.btnFazerLanc.Text = "Fazer Lançamento";
            this.btnFazerLanc.UseVisualStyleBackColor = true;
            this.btnFazerLanc.Click += new System.EventHandler(this.btnFazerLanc_Click);
            // 
            // lblSaldo
            // 
            this.lblSaldo.AutoSize = true;
            this.lblSaldo.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo.ForeColor = System.Drawing.Color.Gold;
            this.lblSaldo.Location = new System.Drawing.Point(489, 133);
            this.lblSaldo.Name = "lblSaldo";
            this.lblSaldo.Size = new System.Drawing.Size(0, 18);
            this.lblSaldo.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(434, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Saldo em Conta Corrente";
            // 
            // dgvUL
            // 
            this.dgvUL.AllowUserToAddRows = false;
            this.dgvUL.AllowUserToDeleteRows = false;
            this.dgvUL.AllowUserToOrderColumns = true;
            this.dgvUL.AutoGenerateColumns = false;
            this.dgvUL.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = "0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.códLanc,
            this.dataLanc,
            this.valorLanc,
            this.tipoLanc});
            this.dgvUL.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvUL.DataSource = this.lançamentoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvUL.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvUL.Location = new System.Drawing.Point(21, 61);
            this.dgvUL.MultiSelect = false;
            this.dgvUL.Name = "dgvUL";
            this.dgvUL.ReadOnly = true;
            this.dgvUL.RowHeadersWidth = 4;
            this.dgvUL.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvUL.ShowCellErrors = false;
            this.dgvUL.ShowCellToolTips = false;
            this.dgvUL.ShowEditingIcon = false;
            this.dgvUL.ShowRowErrors = false;
            this.dgvUL.Size = new System.Drawing.Size(407, 336);
            this.dgvUL.TabIndex = 5;
            // 
            // códLanc
            // 
            this.códLanc.DataPropertyName = "CódLanc";
            this.códLanc.HeaderText = "Código";
            this.códLanc.Name = "códLanc";
            this.códLanc.ReadOnly = true;
            // 
            // dataLanc
            // 
            this.dataLanc.DataPropertyName = "DataLanc";
            this.dataLanc.HeaderText = "Data";
            this.dataLanc.Name = "dataLanc";
            this.dataLanc.ReadOnly = true;
            // 
            // valorLanc
            // 
            this.valorLanc.DataPropertyName = "ValorLanc";
            this.valorLanc.HeaderText = "Valor";
            this.valorLanc.Name = "valorLanc";
            this.valorLanc.ReadOnly = true;
            // 
            // tipoLanc
            // 
            this.tipoLanc.DataPropertyName = "TipoLanc";
            this.tipoLanc.HeaderText = "Tipo";
            this.tipoLanc.Name = "tipoLanc";
            this.tipoLanc.ReadOnly = true;
            // 
            // lançamentoBindingSource
            // 
            this.lançamentoBindingSource.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(157, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(353, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Movimentação - Conta Corrente";
            // 
            // TelaMovCCrr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 432);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TelaMovCCrr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conta Corrente";
            this.Load += new System.EventHandler(this.TelaMovCCrr_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvUL;
        private System.Windows.Forms.Label lblSaldo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAlt;
        private System.Windows.Forms.Button btnExt;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnFazerLanc;
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.BindingSource lançamentoBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn códLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorLanc;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoLanc;
    }
}