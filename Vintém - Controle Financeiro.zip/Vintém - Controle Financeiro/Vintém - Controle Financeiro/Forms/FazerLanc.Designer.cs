﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class FazerLanc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FazerLanc));
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.rdbEnt = new System.Windows.Forms.RadioButton();
            this.rdbSai = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rtbValor = new System.Windows.Forms.RichTextBox();
            this.cbbTipo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mtbData = new System.Windows.Forms.MaskedTextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.ttpCampo = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            this.SuspendLayout();
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 22;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // rdbEnt
            // 
            this.rdbEnt.AutoSize = true;
            this.rdbEnt.Location = new System.Drawing.Point(74, 74);
            this.rdbEnt.Name = "rdbEnt";
            this.rdbEnt.Size = new System.Drawing.Size(62, 17);
            this.rdbEnt.TabIndex = 23;
            this.rdbEnt.TabStop = true;
            this.rdbEnt.Text = "Entrada";
            this.rdbEnt.UseVisualStyleBackColor = true;
            // 
            // rdbSai
            // 
            this.rdbSai.AutoSize = true;
            this.rdbSai.Location = new System.Drawing.Point(74, 97);
            this.rdbSai.Name = "rdbSai";
            this.rdbSai.Size = new System.Drawing.Size(54, 17);
            this.rdbSai.TabIndex = 24;
            this.rdbSai.TabStop = true;
            this.rdbSai.Text = "Saída";
            this.rdbSai.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(93, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 23);
            this.label2.TabIndex = 25;
            this.label2.Text = "Fazer Lançamento";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(183, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 26;
            this.label1.Text = "Valor:";
            // 
            // rtbValor
            // 
            this.rtbValor.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbValor.Location = new System.Drawing.Point(232, 52);
            this.rtbValor.Name = "rtbValor";
            this.rtbValor.Size = new System.Drawing.Size(110, 22);
            this.rtbValor.TabIndex = 27;
            this.rtbValor.Text = "";
            this.rtbValor.Enter += new System.EventHandler(this.RtbValor_Enter);
            // 
            // cbbTipo
            // 
            this.cbbTipo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbTipo.FormattingEnabled = true;
            this.cbbTipo.Items.AddRange(new object[] {
            "Salário",
            "Transferência",
            "Alimentação",
            "Transporte",
            "Lazer",
            "Saúde",
            "Vestuário",
            "Educação",
            "Contas",
            "Outros",
            "Saque"});
            this.cbbTipo.Location = new System.Drawing.Point(232, 84);
            this.cbbTipo.Name = "cbbTipo";
            this.cbbTipo.Size = new System.Drawing.Size(110, 24);
            this.cbbTipo.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(183, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 29;
            this.label3.Text = "Tipo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(183, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 30;
            this.label4.Text = "Data:";
            // 
            // mtbData
            // 
            this.mtbData.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbData.Location = new System.Drawing.Point(232, 120);
            this.mtbData.Mask = "00/00/0000";
            this.mtbData.Name = "mtbData";
            this.mtbData.Size = new System.Drawing.Size(110, 23);
            this.mtbData.TabIndex = 31;
            this.mtbData.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtbData.ValidatingType = typeof(System.DateTime);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(249, 156);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 32;
            this.btnOK.Text = "Ok";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // ttpCampo
            // 
            this.ttpCampo.AutoPopDelay = 5000;
            this.ttpCampo.InitialDelay = 1;
            this.ttpCampo.IsBalloon = true;
            this.ttpCampo.ReshowDelay = 1;
            // 
            // FazerLanc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(387, 214);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.mtbData);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbbTipo);
            this.Controls.Add(this.rtbValor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rdbSai);
            this.Controls.Add(this.rdbEnt);
            this.Controls.Add(this.pctbVoltar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FazerLanc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fazer Lançamento";
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.RadioButton rdbEnt;
        private System.Windows.Forms.RadioButton rdbSai;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rtbValor;
        private System.Windows.Forms.ComboBox cbbTipo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox mtbData;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.ToolTip ttpCampo;
    }
}