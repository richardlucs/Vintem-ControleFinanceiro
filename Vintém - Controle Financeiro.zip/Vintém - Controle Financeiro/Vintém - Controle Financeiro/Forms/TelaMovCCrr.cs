﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaMovCCrr : Form
    {
        string NomeContF;
        string usu;
        ArrayList MeusLançamentos = new ArrayList();
        Lançamento ObjetoLanc = new Lançamento();
        ArrayList DGV = new ArrayList();
        gerCTC Lanc = new gerCTC();

        public TelaMovCCrr(string NomeCF, string usuário)
        {
            InitializeComponent();
            NomeContF = NomeCF;
            usu = usuário;       
        }
 
        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            TelaPrincipal Nova = new TelaPrincipal(usu, NomeContF);
            Hide();
            Nova.Show();
        }

        private void btnFazerLanc_Click(object sender, EventArgs e)
        {
            FazerLanc Nova = new FazerLanc(usu, NomeContF);
            Hide();
            Nova.Show();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ExcLanc Nova = new ExcLanc(usu, NomeContF);
            Hide();
            Nova.Show();
        }

        private void btnAlt_Click(object sender, EventArgs e)
        {
            AltLanc Nova = new AltLanc(usu, NomeContF);
            Hide();
            Nova.Show();
        }

        private void btnExt_Click(object sender, EventArgs e)
        {
            TelaExt Nova = new TelaExt(usu, NomeContF);
            Hide();
            Nova.Show();
        }

        private void TelaMovCCrr_Load(object sender, EventArgs e)
        {
            double saldo = 0;
            MeusLançamentos = Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (x.NomeCF == NomeContF)
                {
                    DGV.Add(x);
                }
            }

            foreach (Lançamento x in DGV)
            {
                dgvUL.DataSource = DGV;
                saldo += x.ValorLanc;
            }

            lblSaldo.Text = "R$ " + saldo.ToString();
        }
    }
}
