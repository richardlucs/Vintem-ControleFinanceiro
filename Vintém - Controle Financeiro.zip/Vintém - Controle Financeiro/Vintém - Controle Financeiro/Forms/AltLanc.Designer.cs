﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class AltLanc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AltLanc));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAlt = new System.Windows.Forms.Button();
            this.mtbData = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbbTipo = new System.Windows.Forms.ComboBox();
            this.rtbValor = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvUL = new System.Windows.Forms.DataGridView();
            this.códLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoLancDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lançamentoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 31;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(263, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 18);
            this.label2.TabIndex = 30;
            this.label2.Text = "Alterar lançamento";
            // 
            // btnAlt
            // 
            this.btnAlt.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlt.Location = new System.Drawing.Point(531, 243);
            this.btnAlt.Name = "btnAlt";
            this.btnAlt.Size = new System.Drawing.Size(75, 23);
            this.btnAlt.TabIndex = 39;
            this.btnAlt.Text = "Alterar";
            this.btnAlt.UseVisualStyleBackColor = true;
            this.btnAlt.Click += new System.EventHandler(this.btnAlt_Click);
            // 
            // mtbData
            // 
            this.mtbData.Location = new System.Drawing.Point(514, 207);
            this.mtbData.Mask = "00/00/0000";
            this.mtbData.Name = "mtbData";
            this.mtbData.Size = new System.Drawing.Size(110, 20);
            this.mtbData.TabIndex = 38;
            this.mtbData.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals;
            this.mtbData.ValidatingType = typeof(System.DateTime);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(465, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 37;
            this.label4.Text = "Data:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(465, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 36;
            this.label3.Text = "Tipo:";
            // 
            // cbbTipo
            // 
            this.cbbTipo.FormattingEnabled = true;
            this.cbbTipo.Items.AddRange(new object[] {
            "Salário",
            "Transferência",
            "Alimentação",
            "Transporte",
            "Lazer",
            "Saúde",
            "Vestuário",
            "Educação",
            "Contas",
            "Outros",
            "Saque"});
            this.cbbTipo.Location = new System.Drawing.Point(514, 171);
            this.cbbTipo.Name = "cbbTipo";
            this.cbbTipo.Size = new System.Drawing.Size(110, 21);
            this.cbbTipo.TabIndex = 35;
            // 
            // rtbValor
            // 
            this.rtbValor.Location = new System.Drawing.Point(514, 139);
            this.rtbValor.Name = "rtbValor";
            this.rtbValor.Size = new System.Drawing.Size(110, 22);
            this.rtbValor.TabIndex = 34;
            this.rtbValor.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(465, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 33;
            this.label1.Text = "Valor:";
            // 
            // dgvUL
            // 
            this.dgvUL.AllowUserToAddRows = false;
            this.dgvUL.AutoGenerateColumns = false;
            this.dgvUL.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvUL.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = "0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.códLancDataGridViewTextBoxColumn,
            this.dataLancDataGridViewTextBoxColumn,
            this.valorLancDataGridViewTextBoxColumn,
            this.tipoLancDataGridViewTextBoxColumn});
            this.dgvUL.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgvUL.DataSource = this.lançamentoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvUL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUL.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dgvUL.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvUL.Location = new System.Drawing.Point(25, 51);
            this.dgvUL.MultiSelect = false;
            this.dgvUL.Name = "dgvUL";
            this.dgvUL.ReadOnly = true;
            this.dgvUL.RowHeadersWidth = 30;
            this.dgvUL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvUL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUL.ShowCellErrors = false;
            this.dgvUL.ShowCellToolTips = false;
            this.dgvUL.ShowEditingIcon = false;
            this.dgvUL.ShowRowErrors = false;
            this.dgvUL.Size = new System.Drawing.Size(434, 336);
            this.dgvUL.TabIndex = 40;
            this.dgvUL.SelectionChanged += new System.EventHandler(this.dgvUL_SelectionChanged);
            // 
            // códLancDataGridViewTextBoxColumn
            // 
            this.códLancDataGridViewTextBoxColumn.DataPropertyName = "CódLanc";
            this.códLancDataGridViewTextBoxColumn.HeaderText = "Código";
            this.códLancDataGridViewTextBoxColumn.Name = "códLancDataGridViewTextBoxColumn";
            this.códLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataLancDataGridViewTextBoxColumn
            // 
            this.dataLancDataGridViewTextBoxColumn.DataPropertyName = "DataLanc";
            this.dataLancDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataLancDataGridViewTextBoxColumn.Name = "dataLancDataGridViewTextBoxColumn";
            this.dataLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // valorLancDataGridViewTextBoxColumn
            // 
            this.valorLancDataGridViewTextBoxColumn.DataPropertyName = "ValorLanc";
            this.valorLancDataGridViewTextBoxColumn.HeaderText = "Valor";
            this.valorLancDataGridViewTextBoxColumn.Name = "valorLancDataGridViewTextBoxColumn";
            this.valorLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tipoLancDataGridViewTextBoxColumn
            // 
            this.tipoLancDataGridViewTextBoxColumn.DataPropertyName = "TipoLanc";
            this.tipoLancDataGridViewTextBoxColumn.HeaderText = "Tipo";
            this.tipoLancDataGridViewTextBoxColumn.Name = "tipoLancDataGridViewTextBoxColumn";
            this.tipoLancDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lançamentoBindingSource
            // 
            this.lançamentoBindingSource.DataSource = typeof(Vintém___Controle_Financeiro.Classes.Lançamento);
            // 
            // AltLanc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 398);
            this.Controls.Add(this.dgvUL);
            this.Controls.Add(this.btnAlt);
            this.Controls.Add(this.mtbData);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbbTipo);
            this.Controls.Add(this.rtbValor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pctbVoltar);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AltLanc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar Lançamento";
            this.Load += new System.EventHandler(this.AltLanc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lançamentoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pctbVoltar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAlt;
        private System.Windows.Forms.MaskedTextBox mtbData;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbbTipo;
        private System.Windows.Forms.RichTextBox rtbValor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource lançamentoBindingSource;
        private System.Windows.Forms.DataGridView dgvUL;
        private System.Windows.Forms.DataGridViewTextBoxColumn códLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorLancDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoLancDataGridViewTextBoxColumn;
    }
}