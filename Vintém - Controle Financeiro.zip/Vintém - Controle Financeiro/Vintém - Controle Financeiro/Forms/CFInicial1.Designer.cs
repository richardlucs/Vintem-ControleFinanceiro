﻿namespace Vintém___Controle_Financeiro.Forms
{
    partial class CFInicial1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CFInicial1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pctbVoltar = new System.Windows.Forms.PictureBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.pctbExcluir = new System.Windows.Forms.PictureBox();
            this.pctbAdicionar = new System.Windows.Forms.PictureBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lblv = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbExcluir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbAdicionar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pctbVoltar);
            this.panel1.Controls.Add(this.lblNome);
            this.panel1.Controls.Add(this.lbl2);
            this.panel1.Controls.Add(this.pctbExcluir);
            this.panel1.Controls.Add(this.pctbAdicionar);
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Controls.Add(this.lblv);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 298);
            this.panel1.TabIndex = 1;
            // 
            // pctbVoltar
            // 
            this.pctbVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbVoltar.Image = ((System.Drawing.Image)(resources.GetObject("pctbVoltar.Image")));
            this.pctbVoltar.InitialImage = null;
            this.pctbVoltar.Location = new System.Drawing.Point(0, 0);
            this.pctbVoltar.Name = "pctbVoltar";
            this.pctbVoltar.Size = new System.Drawing.Size(48, 45);
            this.pctbVoltar.TabIndex = 28;
            this.pctbVoltar.TabStop = false;
            this.pctbVoltar.Click += new System.EventHandler(this.pctbVoltar_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(157, 78);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(0, 23);
            this.lblNome.TabIndex = 27;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(204, 187);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(71, 23);
            this.lbl2.TabIndex = 26;
            this.lbl2.Text = "Excluir";
            // 
            // pctbExcluir
            // 
            this.pctbExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbExcluir.Image = ((System.Drawing.Image)(resources.GetObject("pctbExcluir.Image")));
            this.pctbExcluir.Location = new System.Drawing.Point(167, 175);
            this.pctbExcluir.Name = "pctbExcluir";
            this.pctbExcluir.Size = new System.Drawing.Size(31, 35);
            this.pctbExcluir.TabIndex = 25;
            this.pctbExcluir.TabStop = false;
            this.pctbExcluir.Click += new System.EventHandler(this.pctbExcluir_Click);
            // 
            // pctbAdicionar
            // 
            this.pctbAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pctbAdicionar.Image = ((System.Drawing.Image)(resources.GetObject("pctbAdicionar.Image")));
            this.pctbAdicionar.Location = new System.Drawing.Point(167, 122);
            this.pctbAdicionar.Name = "pctbAdicionar";
            this.pctbAdicionar.Size = new System.Drawing.Size(31, 35);
            this.pctbAdicionar.TabIndex = 24;
            this.pctbAdicionar.TabStop = false;
            this.pctbAdicionar.Click += new System.EventHandler(this.pctbAdicionar_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(204, 134);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(64, 23);
            this.lbl1.TabIndex = 23;
            this.lbl1.Text = "Editar";
            // 
            // lblv
            // 
            this.lblv.AutoSize = true;
            this.lblv.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblv.ForeColor = System.Drawing.Color.Gold;
            this.lblv.Location = new System.Drawing.Point(77, 9);
            this.lblv.Name = "lblv";
            this.lblv.Size = new System.Drawing.Size(292, 32);
            this.lblv.TabIndex = 2;
            this.lblv.Text = "Painel de Controle";
            this.lblv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CFInicial1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 299);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CFInicial1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Controle Financeiro - Tela Inicial";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctbVoltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbExcluir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctbAdicionar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblv;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.PictureBox pctbExcluir;
        private System.Windows.Forms.PictureBox pctbAdicionar;
        private System.Windows.Forms.PictureBox pctbVoltar;
    }
}