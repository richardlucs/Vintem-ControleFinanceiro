﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vintém___Controle_Financeiro.Classes;

namespace Vintém___Controle_Financeiro.Forms
{
    public partial class TelaPrincipal : Form
    {
        string usuário, nomeCF;
        ArrayList MeusLançamentos = new ArrayList();
        Lançamento ObjetoLanc = new Lançamento();
        ArrayList DGV = new ArrayList();
        gerCTC Lanc = new gerCTC();

        public TelaPrincipal(string usu, string CF)
        {
            InitializeComponent();
            usuário = usu;
            nomeCF = CF;
        }

        private void PctbRelat_MouseEnter(object sender, EventArgs e)
        {
            ttpRelat.SetToolTip(pctbRelat, "Relatório");
        }

        private void btnCCrr_Click(object sender, EventArgs e)
        {
            TelaMovCCrr NovaTela = new TelaMovCCrr(nomeCF,usuário);
            Hide();
            NovaTela.Show();
        }

        private void TelaPrincipal_Load(object sender, EventArgs e)
        {
            double saldo = 0;
            MeusLançamentos = Lanc.LerDados();

            foreach (Lançamento x in MeusLançamentos)
            {
                if (x.NomeCF == nomeCF)
                {
                    DGV.Add(x);
                }
            }

            foreach (Lançamento x in DGV)
            {
                dgvUL.DataSource = DGV;
                saldo += x.ValorLanc;
            }

            lblSaldo.Text = "R$ " + saldo.ToString();
        }

        private void pctbRelat_Click(object sender, EventArgs e)
        {
            TelaRelatório NovaT = new TelaRelatório(usuário, nomeCF);
            Hide();
            NovaT.Show();
        }

        private void pctbVoltar_Click(object sender, EventArgs e)
        {
            CFInicial1 NovaTela = new CFInicial1(usuário, nomeCF);
            Hide();
            NovaTela.Show();
        }
    }
}
